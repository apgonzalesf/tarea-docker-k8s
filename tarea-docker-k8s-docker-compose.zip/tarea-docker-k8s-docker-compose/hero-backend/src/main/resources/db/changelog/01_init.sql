CREATE TABLE hero (
    id SERIAL PRIMARY KEY,
    name TEXT
    
);